import React from 'react';
import { Link, useNavigate } from 'react-router-dom'

const Cart = ({ cartItems, removeFromCart}) => {

    const navigate = useNavigate()

    const handleOnConfirm = () => {
        navigate('/orderconfirm', {replace: true})
    }

    return ( 
        <>
            <div>
                <Link to = '/products'>
                <button>Return to Products</button>
                </Link>
            </div>
            <div>
                <h2>Cart Details</h2>
            </div>
            <div>
                <table>
                    <thead>
                        <tr>
                            <th>Index</th>
                            <th>Title</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                            {cartItems.map((item) => {
                                console.log(item)
                                return (
                                    <>
                                     <tr>
                                       <td>{item.id}</td>
                                       <td>{item.title}</td>
                                       <td>
                                         <button onClick = {() => {removeFromCart(item.id)}}>Remove from cart</button>
                                       </td>
                                     </tr>
                                    </>
                                )
                            }
                                
                            )}
                    </tbody>
                </table>
                
                <button onClick = {handleOnConfirm}>confirm Order</button>
                
            </div>
            
        </>
     );
}
 
export default Cart;